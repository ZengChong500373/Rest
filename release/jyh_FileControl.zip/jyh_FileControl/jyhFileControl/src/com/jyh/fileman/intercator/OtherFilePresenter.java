package com.jyh.fileman.intercator;

import java.util.List;
import com.jyh.fileman.FileBean;
import com.jyh.fileman.view.IFileOtherView;

import android.content.Context;
import android.util.SparseArray;

public class OtherFilePresenter implements
		OtherFileInteractor.OnFinishedListener {
	private IFileOtherView mIFileOtherView;
	private Context mContext;
	private OtherFileInteractor mOtherFileInteractor;

	public OtherFilePresenter(IFileOtherView mIFileOtherView, Context mContext) {
		this.mIFileOtherView = mIFileOtherView;
		this.mOtherFileInteractor = new OtherFileInteractorImlp();
		this.mContext = mContext;
	}

	public void searchOther() {
		mOtherFileInteractor.searchOther(mContext, this);
	}

	public void onChildItemClicked(int groupPosition, int childPosition){
		mOtherFileInteractor.onChildItemClicked(groupPosition, childPosition,this);
	}
	@Override
	public void onFinished(SparseArray<List<FileBean>> mSparseArray) {
		mIFileOtherView.showOtherFile(mSparseArray);
	}

}
