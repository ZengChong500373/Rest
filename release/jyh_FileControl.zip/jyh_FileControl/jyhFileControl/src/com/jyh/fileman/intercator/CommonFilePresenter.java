package com.jyh.fileman.intercator;

import java.util.List;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.intercator.CommonFileInteractorImlp.FileType;
import com.jyh.fileman.view.IFileView;

import android.content.Context;

public class CommonFilePresenter implements
		CommonFileInteractor.OnFinishedListener {
	private IFileView mIFileView;
	private Context mContext;
	private CommonFileInteractor mCommonFileInteractor;
	private FileType type;

	public CommonFilePresenter(IFileView mIFileView, Context mContext,
			FileType type) {
		this.mIFileView = mIFileView;
		this.mCommonFileInteractor = new CommonFileInteractorImlp();
		this.type = type;
		this.mContext = mContext;
	}

	public void onStart() {
		mCommonFileInteractor.searchFile(type, mContext, this);
	}

	@Override
	public void onFinished(List<FileBean> List) {
		mIFileView.showFile(List);
	}

	public void onItemClicked(int position) {
		mCommonFileInteractor.onItemClicked(position, this);
	}
}
