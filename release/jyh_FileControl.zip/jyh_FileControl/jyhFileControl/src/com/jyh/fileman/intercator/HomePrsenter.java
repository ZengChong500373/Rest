package com.jyh.fileman.intercator;


import android.util.LongSparseArray;
import android.widget.Toast;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.view.IHomeView;

public class HomePrsenter implements HomeInteractor.OnUploadListener{

	private IHomeView mIHomeView;
	private HomeInteractor mHomeInteractor;
	public HomePrsenter(IHomeView mIHomeView) {
		this.mIHomeView=mIHomeView;
		this.mHomeInteractor=new HomeInteractorImlp();
	}
    public void SendFile(){
    	LongSparseArray<FileBean> mLongSparseArray=mIHomeView.getSparseArray();
    	mHomeInteractor.upLoad(mLongSparseArray,this);
    }
	@Override
	public void onSuccess() {
		
	}
	@Override
	public void onFail() {
		
	}
	

}
