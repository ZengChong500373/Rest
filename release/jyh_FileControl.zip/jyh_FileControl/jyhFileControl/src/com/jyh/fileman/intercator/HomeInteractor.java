package com.jyh.fileman.intercator;

import android.util.LongSparseArray;

import com.jyh.fileman.FileBean;

public interface HomeInteractor {
	interface OnUploadListener{
		void onSuccess();
		void onFail();
	}
	void upLoad(LongSparseArray<FileBean> mLongSparseArray,OnUploadListener mOnUploadListener);

}
