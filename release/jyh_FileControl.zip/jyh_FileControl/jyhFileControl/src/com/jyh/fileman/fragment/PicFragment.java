package com.jyh.fileman.fragment;

import java.util.List;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.R;
import com.jyh.fileman.adapter.PicAdapter;
import com.jyh.fileman.intercator.CommonFilePresenter;
import com.jyh.fileman.intercator.CommonFileInteractorImlp.FileType;
import com.jyh.fileman.view.IFileView;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class PicFragment extends Fragment implements IFileView,AdapterView.OnItemClickListener{
	private View rootView;
	private GridView mGridView;
	private PicAdapter mPicAdapter;
	private CommonFilePresenter mCommonFilePresenter;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Toast.makeText(getActivity(), "PicFragment", 0).show();
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		rootView = View.inflate(getActivity(), R.layout.pic, null);
		initViews();
		return rootView;
	}

	@Override
	public void onResume() {
		super.onResume();
		mCommonFilePresenter=new CommonFilePresenter(this,getActivity(), FileType.pic);
		mCommonFilePresenter.onStart();
	}
	private void initViews() {
		mGridView = (GridView) rootView.findViewById(R.id.mGridView);
		mGridView.setOnItemClickListener(this);
		mPicAdapter = new PicAdapter(getActivity());
		mGridView.setAdapter(mPicAdapter);
	}
	@Override
	public void showFile(List<FileBean> list) {
		mPicAdapter.setData(list);
	}
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		mCommonFilePresenter.onItemClicked(position);
	}
}
