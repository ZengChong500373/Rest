package com.jyh.fileman;

import java.util.HashMap;
import java.util.Map;

import com.jyh.fileman.fragment.MusicFragment;
import com.jyh.fileman.fragment.OtherFragment;
import com.jyh.fileman.fragment.PicFragment;
import com.jyh.fileman.fragment.TxtFragment;
import com.jyh.fileman.fragment.Videofragment;

import android.support.v4.app.Fragment;

public class FragmentFactory {
	private static Map<Integer, Fragment> fragmentMap = new HashMap<Integer, Fragment>();
	public static Fragment createFragment(int position) {
		Fragment fragment = fragmentMap.get(position);
		if (fragment != null) {
			return fragment;
		} else {
			switch (position) {
			case 0:
				fragment = new MusicFragment();
				break;
			case 1:
				fragment = new Videofragment();
				break;
			case 2:
				fragment = new PicFragment();
				break;
			case 3:
				fragment = new TxtFragment();
				break;
			case 4:
				fragment = new OtherFragment();
				break;
			}
			fragmentMap.put(position, fragment);
		}
		return fragment;
	}
}
