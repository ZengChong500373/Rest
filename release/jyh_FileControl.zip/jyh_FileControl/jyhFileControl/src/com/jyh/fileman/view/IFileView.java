package com.jyh.fileman.view;

import java.util.List;

import com.jyh.fileman.FileBean;

public interface IFileView {
	void showFile(List<FileBean> list);
	
}
