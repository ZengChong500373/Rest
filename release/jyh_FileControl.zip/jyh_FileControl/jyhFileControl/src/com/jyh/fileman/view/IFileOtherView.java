package com.jyh.fileman.view;

import java.util.List;
import android.util.SparseArray;

import com.jyh.fileman.FileBean;

public interface IFileOtherView {
	void showOtherFile(SparseArray<List<FileBean>> mSparseArray);
}
