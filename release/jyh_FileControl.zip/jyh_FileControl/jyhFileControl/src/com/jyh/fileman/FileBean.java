package com.jyh.fileman;

public class FileBean implements Comparable<FileBean>{

	/** �ļ�id */
	private Long id;

	/** �ļ����� */
	private String name;
	/** �ļ�·�� */
	private String path;
	/** �ļ�����ʱ��  �� 2016-5-9 10:30*/
	private String time;

	/** �ļ���С */
	private Long size;
	
	/**�ļ�ʱ��ıȽ�*/
	private Long time_compare;
	

	public Long getTime_compare() {
		return time_compare;
	}

	public void setTime_compare(Long time_compare) {
		this.time_compare = time_compare;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public int compareTo(FileBean another) {
		int num=this.getTime_compare().compareTo(another.getTime_compare());
		return -num;
	}
}
