package com.jyh.fileman;
import com.jyh.fileman.view.IHomeView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.app.ActionBarActivity;
import android.text.format.Formatter;
import android.os.Bundle;
import android.util.LongSparseArray;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends ActionBarActivity  implements IHomeView{

	private ViewPager mViewPager;
	private HomeAdapter mHomeAdapter;
	private PagerTab mPagerTab;

	private TextView tv_select_size;
	/**ѡ��Ҫ���͵��ı�����*/
	public  LongSparseArray<FileBean> mSparseArray;
	
	private Button bt_send;
	
       
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initViews();
	}
	private void initViews() {
		tv_select_size = (TextView) findViewById(R.id.tv_select_size);
		bt_send = (Button) findViewById(R.id.bt_send);
		mPagerTab = (PagerTab) findViewById(R.id.pagerTab);
		mViewPager = (ViewPager) findViewById(R.id.mViewPager);
		mViewPager.setPageTransformer(true, new CubeOutTransformer());
		mHomeAdapter=new HomeAdapter(getSupportFragmentManager());
		
		mViewPager.setAdapter(mHomeAdapter);
		mPagerTab.setViewPager(mViewPager);
		mSparseArray=new LongSparseArray<FileBean>();
		mPagerTab.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int arg0) {
				 FragmentFactory.createFragment(arg0);
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});
	}

	class HomeAdapter extends FragmentPagerAdapter {
		private String[] stringArrays;
		public HomeAdapter(FragmentManager fm) {
			super(fm);
			stringArrays=getResources().getStringArray(R.array.tab_names);
		}
		@Override
		public Fragment getItem(int position) {
			return FragmentFactory.createFragment(position);
		}
		@Override
		public int getCount() {
			return stringArrays.length;
		}
		@Override
		public CharSequence getPageTitle(int position) {
			return stringArrays[position];
		}

	}

	@Override
	public void DataChang() {;
		Long size=0L;
		for (int i = 0; i < mSparseArray.size(); i++) {
			size+=mSparseArray.valueAt(i).getSize();
		}
		String formatSize = Formatter.formatFileSize(this, size);
		if(size==0L){
			tv_select_size.setText("��ѡ0B");
		}else{
			tv_select_size.setText("��ѡ"+formatSize);
		}
	}
	@Override
	public LongSparseArray<FileBean> getSparseArray() {
		return mSparseArray;
	}
	@Override
	public void BeyondMaxNum() {
		Toast.makeText(this, "�ļ����ѡ��5��!!!", 0).show();
	}

}
