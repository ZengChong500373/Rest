package com.jyh.fileman.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.HomeActivity;
import com.jyh.fileman.R;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class PicAdapter extends BaseAdapter {
	HomeActivity mHomeActivity; 

	private List<FileBean> listFile;

	private ImageLoader imageLoader;

	private DisplayImageOptions options;
	
	public PicAdapter(Context mContext) {
		this.mHomeActivity = (HomeActivity) mContext;
		listFile = new ArrayList<FileBean>();
		initConfig();
	}

	private void initConfig() {
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(mHomeActivity)
        .memoryCacheExtraOptions(480, 800) // default = device screen dimensions �ڴ滺���ļ�����󳤿�
        .diskCacheExtraOptions(480, 800, null)  // ���ػ������ϸ��Ϣ(�������󳤿�)����ò�Ҫ������� 
        .threadPoolSize(3) // default  �̳߳��ڼ��ص�����
        .threadPriority(Thread.NORM_PRIORITY - 2) // default ���õ�ǰ�̵߳����ȼ�
        .tasksProcessingOrder(QueueProcessingType.FIFO) // default
        .denyCacheImageMultipleSizesInMemory()
        .memoryCache(new LruMemoryCache(2 * 1024 * 1024)) //����ͨ���Լ����ڴ滺��ʵ��
        .memoryCacheSize(2 * 1024 * 1024)  // �ڴ滺������ֵ
        .memoryCacheSizePercentage(13) // default
        .diskCacheSize(50 * 1024 * 1024) // 50 Mb sd��(����)��������ֵ
        .diskCacheFileCount(100)  // ���Ի�����ļ����� 
        .diskCacheFileNameGenerator(new HashCodeFileNameGenerator()) 
        .defaultDisplayImageOptions(DisplayImageOptions.createSimple()) // default
        .writeDebugLogs() // ��ӡdebug log
        .build(); //��ʼ����
		ImageLoader.getInstance().init(config);
		
		 imageLoader = ImageLoader.getInstance();
		 
		// ʹ��DisplayImageOptions.Builder()����DisplayImageOptions
			options = new DisplayImageOptions.Builder()
					.cacheInMemory(true) // �������ص�ͼƬ�Ƿ񻺴����ڴ���
					.cacheOnDisk(true) // �������ص�ͼƬ�Ƿ񻺴���SD����
					.displayer(new RoundedBitmapDisplayer(3)) // ���ó�Բ��ͼƬ
					.build(); // �������
	}
	public void setData(List<FileBean> listFileBeans) {
		this.listFile = listFileBeans;
		
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		if (listFile == null)
			return 0;
		return listFile.size();
	}

	@Override
	public FileBean getItem(int position) {
		if (listFile == null)
			return null;
		return listFile.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		FileBean bean = listFile.get(position);
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = View.inflate(mHomeActivity, R.layout.pic_item, null);
			holder.img = (ImageView) convertView.findViewById(R.id.img);
			holder.check = (ImageView) convertView.findViewById(R.id.check);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		imageLoader.displayImage("file://" + bean.getPath(),
				holder.img, options);
		Boolean isEXIST = (mHomeActivity.mSparseArray.get(bean.getId()) != null);
		if (isEXIST) {
			imageLoader.displayImage("drawable://" + R.drawable.check_checked,
					holder.check, options);
		} else {

			imageLoader.displayImage("drawable://" + R.drawable.check_normal,
					holder.check, options);
		}
		return convertView;

	}

	class ViewHolder {
		ImageView img;
		ImageView check;
		TextView tv;
	}

}
