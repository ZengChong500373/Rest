package com.jyh.fileman.intercator;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.HomeActivity;
import com.jyh.fileman.TimeUtils;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.MediaStore.Files.FileColumns;

public class CommonFileInteractorImlp implements CommonFileInteractor {

	private Uri uri;
	private String selection = null;
	private String[] selectionArgs = null;
	private String data = null;
	private ArrayList<FileBean> listBean;
	
	HomeActivity mHomeActivity; 


	public enum FileType {
		music, video, pic, txt ,other
	};

	@Override
	public void searchFile(FileType type, Context mContext,
			OnFinishedListener listener) {
		switch (type) {
		case music:
			initMusic();
			break;
		case video:
			initVideo();
			break;
		case pic:
			initPic();
			break;
		case txt:
			initTxt();
			break;
		default:
			break;
		}
		mHomeActivity = (HomeActivity) mContext;
		LoadData(mContext);
		Collections.sort(listBean);
		listener.onFinished(listBean);
		clear();
	}

	private void LoadData(Context mContext) {
		listBean = new ArrayList<FileBean>();
		FileBean bean;
		ContentResolver mContentResolver = mContext.getContentResolver();
		Cursor cursor = mContentResolver.query(uri, null, selection,
				selectionArgs, MediaStore.MediaColumns.DATE_MODIFIED);
		if (cursor.moveToFirst()) {
			do {
				String url = cursor.getString(cursor
						.getColumnIndexOrThrow(data));
			
				
				Long id=cursor
						.getLong(cursor
								.getColumnIndexOrThrow(FileColumns._ID));
				File file = new File(url);
				Long size = file.length();
				String time=TimeUtils.getChatTime(file.lastModified());
				bean = new FileBean();
				String[] ss = url.split("/");
				bean.setName(ss[ss.length - 1]);
				bean.setPath(url);
				bean.setTime(time);
				bean.setTime_compare(file.lastModified());
				bean.setSize(size);
				bean.setId(id);
				listBean.add(bean);
			} while (cursor.moveToNext());
		}
	}

	

	public void initMusic() {
		uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
		data = MediaStore.Audio.Media.DATA;
		selection = null;
		selectionArgs = null;

	}

	private void initVideo() {
		uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
		data = MediaStore.Video.Media.DATA;
		selection = null;
		selectionArgs = null;
	}

	private void initPic() {
		uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
		data = MediaStore.Images.Media.DATA;
		selection = null;
		selectionArgs = null;
	}

	private void initTxt() {
		uri = Uri.parse("content://media/external/file");
		selection = MediaStore.MediaColumns.MIME_TYPE
				+ " in (?, ?, ?, ?, ?, ?, ?)";
		selectionArgs = new String[] {
				"text/plain",
				"application/pdf",
				"application/msword",
				"application/vnd.ms-excel",
				"application/msword",
				"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
				"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" };
		data = MediaStore.MediaColumns.DATA;
	}

	@Override
	public void clear() {
		uri = null;
		selection = null;
		selectionArgs = null;
		data = null;
	}

	@Override
	public void onItemClicked(int position, OnFinishedListener listener) {
		if(mHomeActivity.mSparseArray.size()==5){
			mHomeActivity.BeyondMaxNum();
			return;
		}
		FileBean bean = listBean.get(position);
		if (mHomeActivity.mSparseArray.get(bean.getId()) == null) {
			mHomeActivity.mSparseArray.put(bean.getId(), bean);
		} else {
			mHomeActivity.mSparseArray.delete(bean.getId());
		}
		listener.onFinished(listBean);
		mHomeActivity.DataChang();
	}

}
