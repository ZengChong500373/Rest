package com.jyh.fileman.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.text.format.Formatter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.HomeActivity;
import com.jyh.fileman.R;
import com.jyh.fileman.intercator.CommonFileInteractorImlp.FileType;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.decode.BaseImageDecoder;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;

public class CommonFileAdapter extends BaseAdapter {

	HomeActivity mHomeActivity;

	private List<FileBean> listFile;
	private FileType type;
	private Map<FileType, Integer> FileIcon;

	private ImageLoader imageLoader;

	private DisplayImageOptions options;

	public CommonFileAdapter(Context mContext, FileType type) {
		this.mHomeActivity = (HomeActivity) mContext;
		listFile = new ArrayList<FileBean>();
		this.type = type;
		initFileIcon();
		initConfig();
	}

	private void initConfig() {
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				mHomeActivity)
				.memoryCacheExtraOptions(480, 800)
				// default = device screen dimensions �ڴ滺���ļ�����󳤿�
				.diskCacheExtraOptions(480, 800, null)
				// ���ػ������ϸ��Ϣ(�������󳤿�)����ò�Ҫ�������
				.threadPoolSize(3)
				// default �̳߳��ڼ��ص�����
				.threadPriority(Thread.NORM_PRIORITY - 2)
				// default ���õ�ǰ�̵߳����ȼ�
				.tasksProcessingOrder(QueueProcessingType.FIFO)
				// default
				.denyCacheImageMultipleSizesInMemory()
				.memoryCache(new LruMemoryCache(2 * 1024 * 1024))
				// ����ͨ���Լ����ڴ滺��ʵ��
				.memoryCacheSize(2 * 1024 * 1024)
				// �ڴ滺������ֵ
				.memoryCacheSizePercentage(13)
				// default
				.diskCacheSize(50 * 1024 * 1024)
				// 50 Mb sd��(����)��������ֵ
				.diskCacheFileCount(100)
				// ���Ի�����ļ�����
				// defaultΪʹ��HASHCODE��UIL���м��������� ��������MD5(new
				// Md5FileNameGenerator())����
				.diskCacheFileNameGenerator(new HashCodeFileNameGenerator())
				.defaultDisplayImageOptions(DisplayImageOptions.createSimple()) // default
				.writeDebugLogs() // ��ӡdebug log
				.build(); // ��ʼ����
		ImageLoader.getInstance().init(config);

		imageLoader = ImageLoader.getInstance();

		// ʹ��DisplayImageOptions.Builder()����DisplayImageOptions
		options = new DisplayImageOptions.Builder().cacheInMemory(true) // �������ص�ͼƬ�Ƿ񻺴����ڴ���
				.cacheOnDisk(true) // �������ص�ͼƬ�Ƿ񻺴���SD����
				.displayer(new RoundedBitmapDisplayer(3)) // ���ó�Բ��ͼƬ
				.build(); // �������
	}

	private void initFileIcon() {
		FileIcon = new HashMap<FileType, Integer>();
		FileIcon.put(FileType.music, R.drawable.music_icon);
		FileIcon.put(FileType.video, R.drawable.video_icon);
		FileIcon.put(FileType.txt, R.drawable.file_icon);
	}

	public void setData(List<FileBean> listFileBeans) {
		this.listFile = listFileBeans;
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		if (listFile == null)
			return 0;
		return listFile.size();
	}

	@Override
	public FileBean getItem(int position) {
		if (listFile == null)
			return null;
		return listFile.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		FileBean bean = listFile.get(position);
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = View.inflate(mHomeActivity, R.layout.common_item,
					null);
			holder.title = (TextView) convertView.findViewById(R.id.title);
			holder.time = (TextView) convertView.findViewById(R.id.time);
			holder.size = (TextView) convertView.findViewById(R.id.size);
			holder.check = (ImageView) convertView.findViewById(R.id.check);
			holder.img_icon = (ImageView) convertView
					.findViewById(R.id.img_icon);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.title.setText(bean.getName());
		holder.time.setText(bean.getTime());
		String formatSize = Formatter.formatFileSize(mHomeActivity,
				bean.getSize());
		holder.size.setText(formatSize);
		Boolean isEXIST = (mHomeActivity.mSparseArray.get(bean.getId()) != null);
		if (isEXIST) {
			imageLoader.displayImage("drawable://" + R.drawable.check_checked,
					holder.check, options);
		} else {
			imageLoader.displayImage("drawable://" + R.drawable.check_normal,
					holder.check, options);
		}

		imageLoader.displayImage("drawable://" + FileIcon.get(type),
				holder.img_icon, options);
		return convertView;
	}

	class ViewHolder {
		TextView title;
		TextView time;
		TextView size;
		ImageView check;
		ImageView img_icon;
	}

}
