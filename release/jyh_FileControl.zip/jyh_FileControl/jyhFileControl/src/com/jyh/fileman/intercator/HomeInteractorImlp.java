package com.jyh.fileman.intercator;

import android.util.LongSparseArray;

import com.jyh.fileman.FileBean;

public class HomeInteractorImlp implements HomeInteractor{

	@Override
	public void upLoad(LongSparseArray<FileBean> mLongSparseArray,
			OnUploadListener mOnUploadListener) {
		if(mLongSparseArray==null||mLongSparseArray.size()==0)return;
		//�ϴ�
		
	}

	

	
   
	
}
