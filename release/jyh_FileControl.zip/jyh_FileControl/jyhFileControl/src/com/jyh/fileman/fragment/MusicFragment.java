package com.jyh.fileman.fragment;

import java.util.List;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.R;
import com.jyh.fileman.adapter.CommonFileAdapter;
import com.jyh.fileman.intercator.CommonFilePresenter;
import com.jyh.fileman.intercator.CommonFileInteractorImlp.FileType;
import com.jyh.fileman.view.IFileView;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MusicFragment extends Fragment implements IFileView ,AdapterView.OnItemClickListener{
	private View rootView;
	private ListView mListView;
	private CommonFileAdapter mCommonFileAdapter;
	private CommonFilePresenter mCommonFilePresenter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Toast.makeText(getActivity(), "MusicFragment", 0).show();
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		rootView = View.inflate(getActivity(), R.layout.common, null);
		initViews();
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		mCommonFilePresenter = new CommonFilePresenter(this, getActivity(),
				FileType.music);
		mCommonFilePresenter.onStart();
	}

	private void initViews() {
		mListView = (ListView) rootView.findViewById(R.id.mListView);
		mListView.setOnItemClickListener(this);
		mCommonFileAdapter = new CommonFileAdapter(getActivity(),FileType.music);
		mListView.setAdapter(mCommonFileAdapter);
	}

	@Override
	public void showFile(List<FileBean> list) {
		mCommonFileAdapter.setData(list);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		mCommonFilePresenter.onItemClicked(position);
	}
}
