package com.jyh.fileman.intercator;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.HomeActivity;
import com.jyh.fileman.TimeUtils;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.SparseArray;

public class OtherFileInteractorImlp implements OtherFileInteractor {

	private Uri uri;
	private String selection = null;
	private String[] selectionArgs = null;
	private String data = null;
	private ArrayList<FileBean> listBean;

	private SparseArray<List<FileBean>> mSparseArray;

	HomeActivity mHomeActivity;

	@Override
	public void searchOther(Context mContext, OnFinishedListener listener) {
		this.mHomeActivity = (HomeActivity) mContext;
		for (int i = 0; i < 2; i++) {
			if (i == 0) {
				mSparseArray = new SparseArray<List<FileBean>>();
				initZip();
			} else {
				initApk();
			}
			LoadData(mContext);
			if (i == 0 && listBean.size() > 0) {
				mSparseArray.put(0, listBean);
			} else if (listBean.size() > 0) {
				mSparseArray.put(1, listBean);
				listener.onFinished(mSparseArray);
			}
			clear();
		}
	}

	private void LoadData(Context mContext) {
		listBean = new ArrayList<FileBean>();
		FileBean bean;
		ContentResolver mContentResolver = mContext.getContentResolver();
		Cursor cursor = mContentResolver.query(uri, null, selection,
				selectionArgs, MediaStore.MediaColumns.DATE_MODIFIED);
		if (cursor.moveToFirst()) {
			do {
				String url = cursor.getString(cursor
						.getColumnIndexOrThrow(data));
				Long id = cursor.getLong(cursor
						.getColumnIndexOrThrow(MediaStore.MediaColumns._ID));
				File file = new File(url);
				Long size = file.length();
				String time=TimeUtils.getChatTime(file.lastModified());
				bean = new FileBean();
				String[] ss = url.split("/");
				bean.setName(ss[ss.length - 1]);
				bean.setPath(url);
				bean.setTime(time);
				bean.setTime_compare(file.lastModified());
				bean.setSize(size);
				bean.setId(id);
				listBean.add(bean);
				Collections.sort(listBean);
			} while (cursor.moveToNext());
		}
	}

	@Override
	public void onChildItemClicked(int groupPosition, int childPosition,
			OnFinishedListener listener) {
		if(mHomeActivity.mSparseArray.size()==5){
			mHomeActivity.BeyondMaxNum();
			return;
		}
		FileBean bean = mSparseArray.valueAt(groupPosition).get(childPosition);
		if (mHomeActivity.mSparseArray.get(bean.getId()) == null) {
			mHomeActivity.mSparseArray.put(bean.getId(), bean);
		} else {
			mHomeActivity.mSparseArray.delete(bean.getId());
		}
		listener.onFinished(mSparseArray);
		mHomeActivity.DataChang();
	}

	private void initZip() {
		uri = Uri.parse("content://media/external/file");
		selection = MediaStore.MediaColumns.MIME_TYPE + "=?";
		selectionArgs = new String[] { "application/zip" };
		data = MediaStore.MediaColumns.DATA;
	}

	private void initApk() {
		uri = Uri.parse("content://media/external/file");
		selection = MediaStore.MediaColumns.MIME_TYPE + "=?";
		selectionArgs = new String[] { "application/vnd.android.package-archive" };
		data = MediaStore.MediaColumns.DATA;
	}

	@Override
	public void clear() {
		uri = null;
		selection = null;
		selectionArgs = null;
		data = null;
	}

}
