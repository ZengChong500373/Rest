package com.jyh.fileman.adapter;

import java.util.List;

import com.jyh.fileman.ApkUtil;
import com.jyh.fileman.FileBean;
import com.jyh.fileman.HomeActivity;
import com.jyh.fileman.R;
import com.jyh.fileman.TimeUtils;
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.cache.memory.impl.LruMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.content.Context;
import android.text.format.Formatter;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class OtherFileAdapter extends BaseExpandableListAdapter {

	HomeActivity mHomeActivity; 
	private SparseArray<List<FileBean>> mSparseArray;

	private ImageLoader imageLoader;

	private DisplayImageOptions options;
	
	public OtherFileAdapter(Context mContext) {
		this.mHomeActivity = (HomeActivity) mContext;
		mSparseArray = new SparseArray<List<FileBean>>();
		initConfig();
	}
	
	private void initConfig() {
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				mHomeActivity)
				.memoryCacheExtraOptions(480, 800)
				// default = device screen dimensions �ڴ滺���ļ�����󳤿�
				.diskCacheExtraOptions(480, 800, null)
				// ���ػ������ϸ��Ϣ(�������󳤿�)����ò�Ҫ�������
				.threadPoolSize(3)
				// default �̳߳��ڼ��ص�����
				.threadPriority(Thread.NORM_PRIORITY - 2)
				// default ���õ�ǰ�̵߳����ȼ�
				.tasksProcessingOrder(QueueProcessingType.FIFO)
				// default
				.denyCacheImageMultipleSizesInMemory()
				.memoryCache(new LruMemoryCache(2 * 1024 * 1024))
				// ����ͨ���Լ����ڴ滺��ʵ��
				.memoryCacheSize(2 * 1024 * 1024)
				// �ڴ滺������ֵ
				.memoryCacheSizePercentage(13)
				// default
				.diskCacheSize(50 * 1024 * 1024)
				// 50 Mb sd��(����)��������ֵ
				.diskCacheFileCount(100)
				// ���Ի�����ļ�����
				.diskCacheFileNameGenerator(new HashCodeFileNameGenerator())
				.defaultDisplayImageOptions(DisplayImageOptions.createSimple()) // default
				.writeDebugLogs() // ��ӡdebug log
				.build(); // ��ʼ����
		ImageLoader.getInstance().init(config);

		imageLoader = ImageLoader.getInstance();

		// ʹ��DisplayImageOptions.Builder()����DisplayImageOptions
		options = new DisplayImageOptions.Builder().cacheInMemory(true) // �������ص�ͼƬ�Ƿ񻺴����ڴ���
				.cacheOnDisk(true) // �������ص�ͼƬ�Ƿ񻺴���SD����
				.displayer(new RoundedBitmapDisplayer(3)) // ���ó�Բ��ͼƬ
				.build(); // �������
	}

	public void setData(SparseArray<List<FileBean>> mSparseArray) {
		this.mSparseArray = mSparseArray;
		notifyDataSetChanged();
	}

	@Override
	public int getGroupCount() {
		if (mSparseArray == null) {
			return 0;
		}
		return mSparseArray.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return mSparseArray.valueAt(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		if (mSparseArray == null)
			return null;
		return mSparseArray.valueAt(groupPosition);
	}

	@Override
	public FileBean getChild(int groupPosition, int childPosition) {
		return mSparseArray.valueAt(groupPosition).get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		if (mSparseArray == null)
			return 0;
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		if (mSparseArray == null)
			return 0;
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = View.inflate(mHomeActivity, R.layout.other_head, null);
		}
		TextView tv_head = (TextView) convertView.findViewById(R.id.tv_head);
		if (mSparseArray.keyAt(groupPosition) == 0) {
			tv_head.setText("ѹ����");
		} else {
			tv_head.setText("apk");
		}
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		FileBean bean = mSparseArray.valueAt(groupPosition).get(childPosition);
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = View.inflate(mHomeActivity, R.layout.common_item, null);
			holder.title = (TextView) convertView.findViewById(R.id.title);
			holder.time = (TextView) convertView.findViewById(R.id.time);
			holder.size = (TextView) convertView.findViewById(R.id.size);
			holder.check = (ImageView) convertView.findViewById(R.id.check);
			holder.img_icon = (ImageView) convertView.findViewById(R.id.img_icon);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.title.setText(bean.getName());
		holder.time.setText(bean.getTime());
		String formatSize = Formatter.formatFileSize(mHomeActivity, bean.getSize());
		holder.size.setText(formatSize);
		Boolean isEXIST = (mHomeActivity.mSparseArray.get(bean.getId()) != null);
		if (isEXIST) {
			imageLoader.displayImage("drawable://" + R.drawable.check_checked,
					holder.check, options);
		} else {
			imageLoader.displayImage("drawable://" + R.drawable.check_normal,
					holder.check, options);
		}
		if( mSparseArray.keyAt(groupPosition) == 0){
			//"ѹ����"
			imageLoader.displayImage("drawable://" + R.drawable.zip_icon,
					holder.img_icon, options);
		}else{
			//"apk"
			holder.img_icon.setImageDrawable(ApkUtil.loadApkIcon(mHomeActivity, bean.getPath()));
		}
		return convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	class ViewHolder {
		TextView title;
		TextView time;
		TextView size;
		ImageView check;
		ImageView img_icon;
	}
}
