package com.jyh.fileman.fragment;

import java.util.List;

import com.jyh.fileman.FileBean;
import com.jyh.fileman.R;
import com.jyh.fileman.adapter.OtherFileAdapter;
import com.jyh.fileman.intercator.OtherFilePresenter;
import com.jyh.fileman.view.IFileOtherView;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

public class OtherFragment extends Fragment implements IFileOtherView {
	private View rootView;
	private ExpandableListView mExpandableListView;
	private OtherFileAdapter mOtherFileAdapter;
	private OtherFilePresenter mOtherFilePresenter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Toast.makeText(getActivity(), "OtherFragment", 0).show();
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		rootView = View.inflate(getActivity(), R.layout.other, null);
		initViews();
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		mOtherFilePresenter = new OtherFilePresenter(this, getActivity());
		mOtherFilePresenter.searchOther();
	}

	private void initViews() {
		mExpandableListView = (ExpandableListView) rootView
				.findViewById(R.id.mExpandableListView);
		mOtherFileAdapter = new OtherFileAdapter(getActivity());
		mExpandableListView.setAdapter(mOtherFileAdapter);
		mExpandableListView.setGroupIndicator(null);
		
		mExpandableListView.setOnChildClickListener(new OnChildClickListener() {
			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {
				mOtherFilePresenter.onChildItemClicked(groupPosition, childPosition);
				return true;
			}
		});
		
	}

	@Override
	public void showOtherFile(SparseArray<List<FileBean>> mSparseArray) {
		mOtherFileAdapter.setData(mSparseArray);
	}

}
